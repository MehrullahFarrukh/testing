$(document).ready(function () {
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });

    // Global AJAX Search
    const searchInput = $('#globalSearch');
    const resultsBox = $('#searchResults');

    searchInput.on('input', function () {
        const query = $(this).val();
        if (query.length < 2) {
            resultsBox.addClass('d-none').empty();
            return;
        }

        $.ajax({
            url: 'ajax/search.php',
            data: { q: query },
            dataType: 'json',
            success: function (data) {
                resultsBox.empty().removeClass('d-none');
                if (data.length === 0) {
                    resultsBox.append('<div class="p-3 text-dim small">No matches found.</div>');
                } else {
                    data.forEach(item => {
                        let icon = 'fa-tag';
                        let target = 'index.php';
                        if (item.type === 'product') { icon = 'fa-mug-hot'; target = 'menu.php'; }
                        if (item.type === 'stock') { icon = 'fa-box'; target = 'inventory.php'; }
                        if (item.type === 'staff') { icon = 'fa-users'; target = 'labour.php'; }
                        if (item.type === 'vendor') { icon = 'fa-truck'; target = 'vendors.php'; }

                        const html = `
                            <a href="${target}" class="d-flex align-items-center p-3 text-decoration-none border-bottom border-light border-opacity-5 search-result-item">
                                <div class="bg-primary bg-opacity-10 p-2 rounded-3 text-primary me-3">
                                    <i class="fas ${icon} fa-fw"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <div class="fw-bold text-white small">${item.name}</div>
                                    <div class="text-dim extra-small text-uppercase" style="font-size: 0.6rem;">${item.type}</div>
                                </div>
                            </a>
                        `;
                        resultsBox.append(html);
                    });
                }
            }
        });
    });

    // Close search box on click outside
    $(document).on('click', function (e) {
        if (!$(e.target).closest('.search-bar').length) {
            resultsBox.addClass('d-none');
        }
    });
});
