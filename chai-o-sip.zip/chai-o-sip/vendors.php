<?php
require_once 'config/database.php';

if (session_status() === PHP_SESSION_NONE) { session_start(); }
$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['record_payment'])) {
        $vendor_id = $_POST['vendor_id'];
        $amount = $_POST['amount'];
        $date = $_POST['payment_date'];
        $method = $_POST['method'];
        $ref = $_POST['reference'];
        
        if ($vendor_id && $amount > 0) {
            $stmt = $pdo->prepare("INSERT INTO vendor_payments (vendor_id, payment_date, amount, reference) VALUES (?, ?, ?, ?)");
            $stmt->execute([$vendor_id, $date, $amount, $ref]);
            $_SESSION['message'] = ['type' => 'success', 'text' => "Payment of Rs. " . number_format($amount, 2) . " recorded."];
        }
    } elseif (isset($_POST['add_vendor'])) {
        $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_SPECIAL_CHARS);
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_SPECIAL_CHARS);
        
        if ($name) {
            $stmt = $pdo->prepare("INSERT INTO vendors (name, email, phone) VALUES (?, ?, ?)");
            $stmt->execute([$name, $email, $phone]);
            $_SESSION['message'] = ['type' => 'success', 'text' => "Vendor '{$name}' registered successfully."];
        }
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Metrics
$stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) as total FROM vendor_invoices");
$total_invoices = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) as total FROM vendor_payments");
$total_payments = $stmt->fetch()['total'];

$total_payable = $total_invoices - $total_payments;

$stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) as total FROM vendor_payments WHERE MONTH(payment_date) = MONTH(CURDATE()) AND YEAR(payment_date) = YEAR(CURDATE())");
$paid_this_month = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as count FROM vendors");
$active_vendors = $stmt->fetch()['count'];

$stmt = $pdo->query("SELECT COUNT(*) as count FROM vendor_invoices WHERE id NOT IN (SELECT id FROM vendor_payments)"); // Simple logic for demo
$pending_invoices = $stmt->fetch()['count'];

// Transactions
$stmt = $pdo->query("
    SELECT v.name, vi.invoice_date as date, vi.amount, vi.invoice_number as ref, 'invoice' as type, 'Pending' as status
    FROM vendor_invoices vi
    JOIN vendors v ON vi.vendor_id = v.id
    UNION ALL
    SELECT v.name, vp.payment_date as date, vp.amount, vp.reference as ref, 'payment' as type, 'Paid' as status
    FROM vendor_payments vp
    JOIN vendors v ON vp.vendor_id = v.id
    ORDER BY date DESC LIMIT 10
");
$transactions = $stmt->fetchAll();

$stmt = $pdo->query("SELECT id, name FROM vendors ORDER BY name ASC");
$vendor_list = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="mb-4 d-flex justify-content-between align-items-center">
    <div>
        <h2 class="fw-bold mb-1">Supplier Records</h2>
        <p class="text-dim small mb-0">Check what you owe to your suppliers and payment history.</p>
    </div>
    <button class="btn btn-primary px-4 rounded-pill shadow-sm" data-bs-toggle="modal" data-bs-target="#addVendorModal">
        <i class="fas fa-plus me-2"></i> Add Supplier
    </button>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="metric-card">
            <div class="metric-label">My Dues</div>
            <div class="metric-value">Rs. <?= number_format($total_payable, 2) ?> <span class="trend-badge trend-up">+12%</span></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card">
            <div class="metric-label">Paid This Month</div>
            <div class="metric-value">Rs. <?= number_format($paid_this_month, 2) ?> <span class="trend-badge trend-up">+5.2%</span></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card">
            <div class="metric-label">Unpaid Bills</div>
            <div class="metric-value"><?= $pending_invoices ?> <span class="trend-badge" style="background: rgba(255,255,255,0.1); color: var(--text-dim);">-3</span></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card">
            <div class="metric-label">Total Suppliers</div>
            <div class="metric-value"><?= $active_vendors ?> <span class="trend-badge" style="background: rgba(16, 185, 129, 0.1); color: var(--success);">No change</span></div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="card p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="fw-bold mb-0">Transaction History</h5>
                <div class="d-flex gap-2">
                    <button class="btn btn-sm btn-outline-light border-opacity-10"><i class="fas fa-calendar-alt me-2"></i> This Month</button>
                    <button class="btn btn-sm btn-outline-light border-opacity-10"><i class="fas fa-file-export me-2"></i> Export</button>
                    <a href="#" class="text-primary small text-decoration-none ms-2 mt-1">View All</a>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th>Supplier</th>
                            <th>Date</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th class="text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($transactions as $tx): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="bg-primary bg-opacity-10 p-2 rounded-3 me-3 text-primary fw-bold" style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;">
                                        <?= substr($tx['name'], 0, 1) ?>
                                    </div>
                                    <div>
                                        <div class="fw-bold text-white small"><?= htmlspecialchars($tx['name']) ?></div>
                                        <div class="text-dim small" style="font-size: 0.65rem;"><?= htmlspecialchars($tx['ref']) ?></div>
                                    </div>
                                </div>
                            </td>
                            <td class="small text-muted"><?= date('M d, Y', strtotime($tx['date'])) ?></td>
                            <td class="fw-bold">Rs. <?= number_format($tx['amount'], 2) ?></td>
                            <td>
                                <span class="badge-pill <?= $tx['status'] == 'Paid' ? 'trend-up' : 'trend-down' ?>" style="font-size: 0.65rem;">
                                    <i class="fas fa-circle fa-2xs me-1"></i> <?= $tx['status'] ?>
                                </span>
                            </td>
                            <td class="text-end">
                                <i class="fas fa-ellipsis-v text-dim"></i>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <div class="card p-4">
            <h5 class="fw-bold mb-4 d-flex align-items-center">
                <div class="bg-primary p-2 rounded-circle me-3 d-inline-flex" style="width: 32px; height: 32px; align-items: center; justify-content: center;">
                    <i class="fas fa-plus text-white fa-xs"></i>
                </div>
                Pay Supplier
            </h5>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label small fw-bold">Supplier Name</label>
                    <select name="vendor_id" class="form-select" required>
                        <option value="">Select a supplier</option>
                        <?php foreach($vendor_list as $vl): ?>
                            <option value="<?= $vl['id'] ?>"><?= htmlspecialchars($vl['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-6">
                        <label class="form-label small fw-bold">Amount (Rs.)</label>
                        <input type="number" step="0.01" name="amount" class="form-control" placeholder="0.00" required>
                    </div>
                    <div class="col-6">
                        <label class="form-label small fw-bold">Date</label>
                        <input type="date" name="payment_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold">Payment Method</label>
                    <div class="d-flex gap-2">
                         <div class="flex-fill">
                            <input type="radio" class="btn-check" name="method" id="method1" value="Transfer" checked>
                            <label class="btn btn-outline-light border-opacity-10 w-100 py-3 d-flex flex-column align-items-center gap-2" for="method1">
                                <i class="fas fa-university fs-5"></i>
                                <span style="font-size: 0.6rem;">Transfer</span>
                            </label>
                        </div>
                        <div class="flex-fill">
                            <input type="radio" class="btn-check" name="method" id="method2" value="Card">
                            <label class="btn btn-outline-light border-opacity-10 w-100 py-3 d-flex flex-column align-items-center gap-2" for="method2">
                                <i class="fas fa-credit-card fs-5"></i>
                                <span style="font-size: 0.6rem;">Card</span>
                            </label>
                        </div>
                        <div class="flex-fill">
                            <input type="radio" class="btn-check" name="method" id="method3" value="Cash">
                            <label class="btn btn-outline-light border-opacity-10 w-100 py-3 d-flex flex-column align-items-center gap-2" for="method3">
                                <i class="fas fa-money-bill fs-5"></i>
                                <span style="font-size: 0.6rem;">Cash</span>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="mb-4">
                    <label class="form-label small fw-bold">Reference / Notes</label>
                    <textarea name="reference" class="form-control" rows="3" placeholder="Enter transaction reference..."></textarea>
                </div>
                <button type="submit" name="record_payment" class="btn btn-primary w-100 rounded-pill py-3 fw-bold">Submit Payment</button>
            </form>
        </div>
        
        <div class="card p-4 bg-primary text-white border-0 mt-4 shadow-lg overflow-hidden position-relative">
            <div style="position: absolute; right: -20px; bottom: -20px; opacity: 0.1;">
                <i class="fas fa-wallet fa-6x"></i>
            </div>
            <div class="position-relative">
                <div class="small fw-medium opacity-75 mb-1">Monthly Budget Remaining</div>
                <div class="fs-2 fw-bold mb-3">Rs. 24,800.00</div>
                <div class="progress bg-white bg-opacity-20" style="height: 6px;">
                    <div class="progress-bar bg-white" style="width: 65%"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<!-- Add Vendor Modal -->
<div class="modal fade" id="addVendorModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-card border-0 shadow-lg">
            <form method="POST">
                <div class="modal-header border-light border-opacity-10 p-4">
                    <h5 class="modal-title fw-bold">Add New Supplier</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Supplier Name</label>
                        <input type="text" name="name" class="form-control py-3" placeholder="e.g. Al-Madina Traders" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Contact Person / Email</label>
                        <input type="email" name="email" class="form-control py-3" placeholder="vendor@example.com">
                    </div>
                    <div class="mb-0">
                        <label class="form-label small fw-bold">Phone Number</label>
                        <input type="text" name="phone" class="form-control py-3" placeholder="+92 XXX XXXXXXX">
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="submit" name="add_vendor" class="btn btn-primary w-100 rounded-pill py-3 fw-bold shadow-lg">Save Supplier</button>
                </div>
            </form>
        </div>
    </div>
</div>

