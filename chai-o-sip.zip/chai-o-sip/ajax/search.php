<?php
require_once '../config/database.php';

$query = $_GET['q'] ?? '';
$results = [];

if (strlen($query) >= 2) {
    $searchTerm = "%$query%";

    // 1. Search Products (Menu)
    $stmt = $pdo->prepare("SELECT id, name, price, category, 'product' as type FROM products WHERE name LIKE ? OR category LIKE ? LIMIT 5");
    $stmt->execute([$searchTerm, $searchTerm]);
    $results = array_merge($results, $stmt->fetchAll());

    // 2. Search Inventory (Stock)
    $stmt = $pdo->prepare("SELECT id, item_name as name, category, 'stock' as type FROM inventory WHERE item_name LIKE ? OR category LIKE ? LIMIT 5");
    $stmt->execute([$searchTerm, $searchTerm]);
    $results = array_merge($results, $stmt->fetchAll());

    // 3. Search Staff (Labour)
    $stmt = $pdo->prepare("SELECT id, name, 'staff' as type FROM labour WHERE name LIKE ? LIMIT 5");
    $stmt->execute([$searchTerm]);
    $results = array_merge($results, $stmt->fetchAll());

    // 4. Search Suppliers (Vendors)
    $stmt = $pdo->prepare("SELECT id, name, 'vendor' as type FROM vendors WHERE name LIKE ? LIMIT 5");
    $stmt->execute([$searchTerm]);
    $results = array_merge($results, $stmt->fetchAll());
}

header('Content-Type: application/json');
echo json_encode($results);
?>
