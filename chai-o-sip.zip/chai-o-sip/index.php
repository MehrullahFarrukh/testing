<?php
require_once 'config/database.php';

// Ensure 'products' table exists (Silent check)
try { $pdo->exec("CREATE TABLE IF NOT EXISTS products (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, price DECIMAL(10,2) NOT NULL, category VARCHAR(100), image_url VARCHAR(255), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)"); } catch (PDOException $e) {}

// Fetch Metrics
$stmt = $pdo->prepare("SELECT SUM(amount) as total FROM sales WHERE sale_date = CURDATE()");
$stmt->execute();
$daily_sales = $stmt->fetch()['total'] ?? 0;

$stmt = $pdo->prepare("SELECT SUM(amount) as total FROM sales WHERE MONTH(sale_date) = MONTH(CURDATE()) AND YEAR(sale_date) = YEAR(CURDATE())");
$stmt->execute();
$monthly_sales = $stmt->fetch()['total'] ?? 0;

$stmt = $pdo->query("SELECT (SUM(total_received) - SUM(total_used)) as available FROM inventory");
$total_stock = $stmt->fetch()['available'] ?? 0;

$stmt = $pdo->query("
    SELECT 
    (SELECT COALESCE(SUM(amount), 0) FROM vendor_invoices) - 
    (SELECT COALESCE(SUM(amount), 0) FROM vendor_payments) as remaining_balance
");
$vendor_balance = $stmt->fetch()['remaining_balance'] ?? 0;

// Fetch Recent Activity for the table
$stmt = $pdo->query("SELECT 'sale' as type, amount, sale_date as date, description, table_name, created_at FROM sales 
                    UNION ALL 
                    SELECT 'expense' as type, amount, expense_date as date, description as description, 'N/A' as table_name, created_at FROM expenses 
                    ORDER BY created_at DESC LIMIT 5");
$activities = $stmt->fetchAll();

// Fetch Weekly Sales for Chart
$stmt = $pdo->query("SELECT DATE(sale_date) as day, SUM(amount) as total FROM sales WHERE sale_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) GROUP BY DATE(sale_date) ORDER BY DATE(sale_date) ASC");
$weekly_sales = $stmt->fetchAll();
$chart_labels = []; $chart_data = [];
foreach($weekly_sales as $row) {
    $chart_labels[] = date('D', strtotime($row['day']));
    $chart_data[] = (float)$row['total'];
}
$labels_json = json_encode($chart_labels);
$data_json = json_encode($chart_data);

include 'includes/header.php';
?>

<div class="mb-4">
    <h2 class="fw-bold mb-1">Quick View</h2>
    <p class="text-dim small">Track your sales, stock, and what you owe to suppliers.</p>
</div>

<!-- Metrics Row -->
<div class="row g-4 mb-5">
    <div class="col-md-3">
        <div class="metric-card">
            <div class="metric-label">My Dues</div>
            <div class="metric-value">
                Rs. <?= number_format($vendor_balance, 2) ?>
                <span class="trend-badge trend-up">+12%</span>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card">
            <div class="metric-label">Sales Today</div>
            <div class="metric-value">
                Rs. <?= number_format($daily_sales, 2) ?>
                <span class="trend-badge trend-up">+5.2%</span>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card">
            <div class="metric-label">Monthly Sales</div>
            <div class="metric-value">
                Rs. <?= number_format($monthly_sales, 2) ?>
                <span class="trend-badge trend-down">-3%</span>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card">
            <div class="metric-label">Current Stock</div>
            <div class="metric-value">
                <?= number_format($total_stock, 0) ?>
                <span class="trend-badge bg-light text-dim">Units</span>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-5">
    <!-- Weekly Sales Graph -->
    <div class="col-lg-8">
        <div class="card h-100 p-4">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <div>
                    <h5 class="fw-bold mb-0">Weekly Sales Graph</h5>
                    <p class="text-dim extra-small mb-0">Total daily income for this week.</p>
                </div>
                <a href="reports.php" class="text-primary small text-decoration-none">Details</a>
            </div>
            <div style="height: 300px;">
                <canvas id="salesChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Cafe Management -->
    <div class="col-lg-4">
        <div class="card h-100 p-4" style="background: var(--bg-surface);">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h5 class="fw-bold mb-0">Menu Overview</h5>
                <a href="menu.php" class="text-primary small text-decoration-none">Manage Menu</a>
            </div>
            <div class="d-flex flex-column gap-3">
                <?php
                $stmt = $pdo->query("SELECT category, COUNT(*) as count FROM products GROUP BY category");
                $cat_counts = $stmt->fetchAll();
                foreach($cat_counts as $cat):
                ?>
                <div class="d-flex justify-content-between align-items-center bg-input p-3 rounded-pill">
                    <span class="text-white small fw-bold px-3"><?= htmlspecialchars($cat['category']) ?></span>
                    <span class="badge rounded-pill bg-primary px-3 py-2"><?= $cat['count'] ?> Items</span>
                </div>
                <?php endforeach; ?>
            </div>
            <a href="sales.php" class="btn btn-primary w-100 rounded-pill py-3 mt-4 fw-bold shadow">
                <i class="fas fa-shopping-basket me-2"></i> Open Cafe POS
            </a>
            <div class="mt-3 text-center">
                <a href="expenses.php" class="text-dim extra-small text-decoration-none me-3"><i class="fas fa-receipt me-1"></i> Add Expense</a>
                <a href="inventory.php" class="text-dim extra-small text-decoration-none"><i class="fas fa-boxes me-1"></i> Check Stock</a>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Latest Updates Table -->
    <div class="col-lg-12">
        <div class="card p-4">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h5 class="fw-bold mb-0">Latest Updates</h5>
                <a href="reports.php" class="text-primary small text-decoration-none">View All</a>
            </div>
            <div class="table-responsive bg-card">
                <table class="table align-middle mb-0 table-dark">
                    <thead>
                        <tr>
                            <th>What Happened?</th>
                            <th>When?</th>
                            <th>Amount</th>
                            <th class="text-end">Result</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($activities as $act): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="bg-primary bg-opacity-10 p-2 rounded-circle me-3" style="width: 36px; height: 36px; display: flex; align-items: center; justify-content: center;">
                                        <i class="fas <?= $act['type'] == 'sale' ? 'fa-arrow-up text-success' : 'fa-arrow-down text-danger' ?> fa-xs"></i>
                                    </div>
                                    <div>
                                        <div class="fw-bold small"><?= ucfirst($act['type']) ?> Entry - <?= htmlspecialchars($act['table_name']) ?></div>
                                        <div class="text-dim small" style="font-size: 0.65rem;"><?= htmlspecialchars(substr($act['description'] ?? '', 0, 50)) ?>...</div>
                                    </div>
                                </div>
                            </td>
                            <td class="small text-muted"><?= date('M d, Y', strtotime($act['date'])) ?></td>
                            <td class="fw-bold">Rs. <?= number_format($act['amount'], 2) ?></td>
                            <td class="text-end">
                                <span class="badge-pill <?= $act['type'] == 'sale' ? 'trend-up' : 'trend-down' ?>" style="font-size: 0.65rem;">
                                    <?= $act['type'] == 'sale' ? 'Income' : 'Cost' ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
const ctx = document.getElementById('salesChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: <?= $labels_json ?>,
        datasets: [{
            label: 'Sales Income(Rs.)',
            data: <?= $data_json ?>,
            borderColor: '#2563eb',
            backgroundColor: 'rgba(37, 99, 235, 0.1)',
            fill: true,
            tension: 0.4,
            pointRadius: 4,
            pointBackgroundColor: '#2563eb'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#64748b' } },
            x: { grid: { display: false }, ticks: { color: '#64748b' } }
        }
    }
});
</script>

<?php include 'includes/footer.php'; ?>

