<?php
require_once 'config/database.php';

if (session_status() === PHP_SESSION_NONE) { session_start(); }
$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_item'])) {
        $name = filter_input(INPUT_POST, 'item_name', FILTER_SANITIZE_SPECIAL_CHARS);
        $sku = filter_input(INPUT_POST, 'sku', FILTER_SANITIZE_SPECIAL_CHARS);
        $category = filter_input(INPUT_POST, 'category', FILTER_SANITIZE_SPECIAL_CHARS);
        $price = filter_input(INPUT_POST, 'unit_price', FILTER_VALIDATE_FLOAT);
        $unit = filter_input(INPUT_POST, 'unit_type', FILTER_SANITIZE_SPECIAL_CHARS);
        $min = filter_input(INPUT_POST, 'min_threshold', FILTER_VALIDATE_INT);
        
        if ($name && $min !== false) {
            $stmt = $pdo->prepare("INSERT INTO inventory (item_name, sku, category, unit_price, unit_type, total_received, total_used, min_threshold) VALUES (?, ?, ?, ?, ?, 0, 0, ?)");
            $stmt->execute([$name, $sku, $category, $price, $unit, $min]);
            $_SESSION['message'] = ['type' => 'success', 'text' => "Item '{$name}' registered successfully."];
        }
    } elseif (isset($_POST['update_stock'])) {
        $id = $_POST['item_id'];
        $adj_type = $_POST['adj_type'];
        $qty_amt = abs((float)$_POST['qty_amt']);
        
        if ($qty_amt > 0) {
            if ($adj_type === 'add') {
                $stmt = $pdo->prepare("UPDATE inventory SET total_received = total_received + ? WHERE id = ?");
            } else {
                $stmt = $pdo->prepare("UPDATE inventory SET total_used = total_used + ? WHERE id = ?");
            }
            $stmt->execute([$qty_amt, $id]);
            $_SESSION['message'] = ['type' => 'success', 'text' => "Stock successfully " . ($adj_type === 'add' ? 'added' : 'deducted') . "."];
        }
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

$stmt = $pdo->query("SELECT *, (total_received - total_used) as available FROM inventory ORDER BY item_name ASC");
$items = $stmt->fetchAll();

$total_items = count($items);
$total_value = 0;
$low_stock = 0; $out_of_stock = 0;
foreach($items as $item) {
    $total_value += ($item['available'] * $item['unit_price']);
    if($item['available'] <= 0) $out_of_stock++;
    elseif($item['available'] < $item['min_threshold']) $low_stock++;
}

include 'includes/header.php';
?>

<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h2 class="fw-bold mb-1">Stock Manager</h2>
    </div>
    <button class="btn btn-primary px-4 rounded-pill shadow-sm" data-bs-toggle="modal" data-bs-target="#addItemModal">
        <i class="fas fa-plus me-2"></i> Add Item
    </button>
</div>

<div class="card p-0 overflow-hidden border-0 shadow-sm mb-4">
    <div class="p-4 bg-surface border-bottom border-light border-opacity-10">
        <h5 class="fw-bold mb-1">My Stock List</h5>
        <p class="text-dim small mb-0">Check what you have in hand and what needs more stock.</p>
    </div>
    <div class="table-responsive bg-card">
        <table class="table align-middle mb-0 table-dark">
            <thead>
                <tr>
                    <th class="ps-4">Item Name</th>
                    <th>Item Code</th>
                    <th>Category</th>
                    <th>Available</th>
                    <th>Status</th>
                    <th class="text-end pe-4">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): 
                    $status = 'In Stock';
                    $badge = 'trend-up';
                    if($item['available'] <= 0) { $status = 'Out of Stock'; $badge = 'trend-down'; }
                    elseif($item['available'] < $item['min_threshold']) { $status = 'Low Stock'; $badge = 'bg-warning text-white'; }
                ?>
                <tr>
                    <td class="ps-4">
                        <div class="fw-bold text-white"><?= htmlspecialchars($item['item_name']) ?></div>
                        <div class="text-dim small" style="font-size: 0.65rem;">Premium All-Purpose</div>
                    </td>
                    <td class="text-dim small fw-medium"><?= htmlspecialchars($item['sku'] ?: 'N/A') ?></td>
                    <td><span class="badge border border-light border-opacity-10 text-dim fw-bold" style="font-size: 0.65rem; background: var(--bg-surface);"><?= htmlspecialchars($item['category'] ?: 'General') ?></span></td>
                    <td class="fw-bold"><?= $item['available'] ?> <?= $item['unit_type'] ?></td>
                    <td>
                        <div class="d-flex align-items-center">
                            <span class="badge-pill <?= $badge ?>" style="font-size: 0.65rem; padding: 4px 10px;">
                                <i class="fas fa-circle fa-2xs me-1"></i> <?= $status ?>
                            </span>
                        </div>
                    </td>
                    <td class="text-end pe-4">
                        <div class="d-flex justify-content-end gap-2">
                             <button class="btn btn-sm btn-link text-dim p-0" data-bs-toggle="modal" data-bs-target="#updateModal<?= $item['id'] ?>">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-link text-dim p-0">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    </td>
                </tr>

                <!-- Update Modal -->
                <div class="modal fade" id="updateModal<?= $item['id'] ?>" tabindex="-1">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content bg-card border-0 shadow-lg border-light border-opacity-10">
                            <form method="POST">
                                <div class="modal-header border-light border-opacity-10 p-4">
                                    <h5 class="modal-title fw-bold">Update Stock: <span class="text-primary"><?= htmlspecialchars($item['item_name']) ?></span></h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body p-4">
                                    <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                                    <div class="mb-3">
                                        <div class="d-flex justify-content-between text-dim small fw-bold mb-2">
                                            <span>Current Stock:</span>
                                            <span class="<?= $item['available'] <= 0 ? 'text-danger' : 'text-success' ?>"><?= $item['available'] ?> <?= $item['unit_type'] ?></span>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label class="form-label small fw-bold text-dim">What to do?</label>
                                        <div class="search-bar w-100 py-0 px-3 bg-input">
                                            <i class="fas fa-exchange-alt text-primary"></i>
                                            <select name="adj_type" class="form-select bg-transparent border-0 text-white shadow-none py-3" required>
                                                <option value="add" style="background:var(--bg-card);">Add Stock (+)</option>
                                                <option value="deduct" style="background:var(--bg-card);">Remove Stock (-)</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label class="form-label small fw-bold text-dim">Quantity (<?= $item['unit_type'] ?>)</label>
                                        <div class="search-bar w-100 py-1 px-3 bg-input">
                                            <i class="fas fa-boxes text-dim"></i>
                                            <input type="number" step="0.01" min="0.01" name="qty_amt" class="form-control bg-transparent border-0 text-white shadow-none fs-5 py-2" placeholder="0" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer border-0 p-4 pt-0">
                                    <button type="submit" name="update_stock" class="btn btn-primary w-100 rounded-pill py-3 fw-bold shadow-lg">Save Changes</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="p-3 bg-surface border-top border-light border-opacity-10 d-flex align-items-center justify-content-between">
        <span class="text-dim small">Showing 1 to <?= $total_items ?> of <?= $total_items ?> results</span>
        <nav>
            <ul class="pagination pagination-sm mb-0 gap-1">
                <li class="page-item"><a class="page-link bg-card border-0 rounded-start" href="#"><i class="fas fa-chevron-left"></i></a></li>
                <li class="page-item active"><a class="page-link bg-primary border-0" href="#">1</a></li>
                <li class="page-item"><a class="page-link bg-card border-0" href="#">2</a></li>
                <li class="page-item"><a class="page-link bg-card border-0 rounded-end" href="#"><i class="fas fa-chevron-right"></i></a></li>
            </ul>
        </nav>
    </div>
</div>

<!-- Summary Cards (Matching Image 1) -->
<div class="row g-4 mt-1">
    <div class="col-md-3">
        <div class="metric-card h-100 p-4">
            <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="metric-label mb-0">TOTAL ITEMS</div>
                <i class="fas fa-box-open text-primary opacity-50"></i>
            </div>
            <div class="metric-value fs-2 mb-1"><?= number_format($total_items) ?></div>
            <div class="text-success small fw-bold"><i class="fas fa-arrow-up me-1"></i> +12% from last month</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card h-100 p-4">
            <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="metric-label mb-0">OUT OF STOCK</div>
                <i class="fas fa-exclamation-triangle text-danger opacity-50"></i>
            </div>
            <div class="metric-value fs-2 text-danger mb-1"><?= $out_of_stock ?></div>
            <div class="text-dim small">Requires immediate attention</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card h-100 p-4">
            <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="metric-label mb-0">LOW STOCK</div>
                <i class="fas fa-bell text-warning opacity-50"></i>
            </div>
            <div class="metric-value fs-2 text-warning mb-1"><?= $low_stock ?></div>
            <div class="text-warning small fw-bold"><?= $low_stock ?> items in procurement</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card h-100 p-4">
            <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="metric-label mb-0">TOTAL WORTH</div>
                <i class="fas fa-money-bill-wave text-success opacity-50"></i>
            </div>
            <div class="metric-value fs-2 mb-1">Rs. <?= number_format($total_value, 0) ?></div>
            <div class="text-dim small">Total value of stock</div>
        </div>
    </div>
</div>

<!-- Add Item Modal -->
<div class="modal fade" id="addItemModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-card border-0 shadow-lg" style="border: 1px solid var(--border) !important;">
            <form method="POST">
                <div class="modal-header border-light border-opacity-10">
                    <h5 class="modal-title fw-bold">Add New Item</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label small fw-bold">Item Name</label>
                            <input type="text" name="item_name" class="form-control" placeholder="Organic Flour, etc." required>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Item Code (Optional)</label>
                            <input type="text" name="sku" class="form-control" placeholder="FLR-001">
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Category</label>
                            <input type="text" name="category" class="form-control" placeholder="Ingredients">
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Unit Price</label>
                            <input type="number" step="0.01" name="unit_price" class="form-control" placeholder="0.00">
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Unit Type</label>
                            <input type="text" name="unit_type" class="form-control" placeholder="kg, units, etc.">
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Alert when stock is below</label>
                            <input type="number" name="min_threshold" class="form-control" value="5" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 p-3">
                    <button type="submit" name="add_item" class="btn btn-primary w-100 rounded-pill">Add Item to Catalog</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.pagination .page-link {
    color: var(--text-muted);
    padding: 6px 12px;
}
.pagination .page-item.active .page-link {
    background-color: var(--primary) !important;
}
</style>

<?php include 'includes/footer.php'; ?>


