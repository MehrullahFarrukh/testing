<?php
require_once 'config/database.php';

$date = $_GET['date'] ?? date('Y-m-d'); // Default to today's date

// Fetch Metrics
$stmt = $pdo->prepare("SELECT SUM(amount) as total FROM sales WHERE sale_date = ?");
$stmt->execute([$date]);
$total_sales = $stmt->fetch()['total'] ?? 0.00;

$stmt = $pdo->prepare("SELECT SUM(amount) as total FROM expenses WHERE expense_date = ?");
$stmt->execute([$date]);
$total_expenses = $stmt->fetch()['total'] ?? 0.00;

$labour_costs = 0.00; // Updated dynamically below
$net_profit = $total_sales - $total_expenses - $labour_costs;

$stmt = $pdo->prepare("SELECT * FROM sales WHERE sale_date = ?");
$stmt->execute([$date]);
$sales_items = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="mb-4 d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center">
        <div class="bg-primary p-2 rounded-3 me-3 text-white">
            <i class="fas fa-chart-line"></i>
        </div>
        <h2 class="fw-bold mb-0">Business ERP</h2>
        <nav class="ms-5 d-none d-md-flex gap-4">
             <a href="index.php" class="text-dim text-decoration-none small">Dashboard</a>
             <a href="sales.php" class="text-dim text-decoration-none small">Sales</a>
             <a href="expenses.php" class="text-dim text-decoration-none small">Expenses</a>
             <a href="inventory.php" class="text-dim text-decoration-none small">Inventory</a>
             <a href="vendors.php" class="text-dim text-decoration-none small">Vendors</a>
        </nav>
    </div>
    <div class="d-flex gap-2 no-print">
        <button class="btn btn-primary rounded-pill px-4" onclick="window.print()">
            <i class="fas fa-print me-2"></i> Print...
        </button>
        <div class="bg-light p-2 rounded-circle overflow-hidden shadow-sm" style="width: 40px; height: 40px;">
            <img src="https://ui-avatars.com/api/?name=Alex+Rivera&background=0D8ABC&color=fff" width="100%" alt="">
        </div>
    </div>
</div>

<div class="mb-5">
    <div class="text-dim small mb-1">Reports > Chalan View</div>
    <h1 class="fw-bold mb-1">Business Summary Chalan</h1>
    <p class="text-dim small">Final list for daily operations: <?= date('d M Y', strtotime($date)) ?></p>
</div>

<!-- Summary Cards -->
<div class="row g-4 mb-5">
    <div class="col-md-3">
        <div class="card p-4 bg-surface border-0 shadow-sm border-start border-4 border-primary">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <div class="small text-dim">Total Sales</div>
                <i class="fas fa-chart-line text-primary"></i>
            </div>
            <div class="fs-3 fw-bold text-white mb-2">Rs. <?= number_format($total_sales, 2) ?></div>
            <div class="badge-pill trend-up d-inline-block" style="font-size: 0.65rem;">+12.5% from yesterday</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card p-4 bg-surface border-0 shadow-sm border-start border-4 border-danger">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <div class="small text-dim">Total Expenses</div>
                <i class="fas fa-wallet text-danger"></i>
            </div>
            <div class="fs-3 fw-bold text-white mb-2">Rs. <?= number_format($total_expenses, 2) ?></div>
            <div class="badge-pill trend-down d-inline-block" style="font-size: 0.65rem;">+5.2% from avg</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card p-4 bg-surface border-0 shadow-sm border-start border-4 border-warning">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <div class="small text-dim">Labour Costs</div>
                <i class="fas fa-users-gear text-warning"></i>
            </div>
            <div class="fs-3 fw-bold text-white mb-2">Rs. <?= number_format($labour_costs, 2) ?></div>
            <div class="badge border border-light border-opacity-10 text-dim d-inline-block" style="font-size: 0.65rem;">Stable vs last week</div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card p-4 bg-surface border-0 shadow-sm border-start border-4 border-success">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <div class="small text-dim">Net Profit</div>
                <i class="fas fa-money-bill-trend-up text-success"></i>
            </div>
            <div class="fs-3 fw-bold text-white mb-2">Rs. <?= number_format($net_profit, 2) ?></div>
            <div class="badge-pill trend-up d-inline-block" style="font-size: 0.65rem;">+15.2% target reached</div>
        </div>
    </div>
</div>

<div class="row g-5">
    <div class="col-lg-12">
        <div class="mb-4 d-flex justify-content-between align-items-end">
            <h5 class="fw-bold mb-0">Daily Sales Summary</h5>
            <div class="text-dim extra-small">Generated at 18:45 PM</div>
        </div>
        <div class="card p-0 border-0 bg-surface shadow-sm mb-5">
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr class="bg-card">
                            <th class="ps-4">TABLE / SPACE</th>
                            <th>ITEMS DESCRIPTION</th>
                            <th class="text-end pe-4">TOTAL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($sales_items)): ?>
                        <tr><td colspan="3" class="text-center py-4 text-dim small">No sales recorded for this date.</td></tr>
                        <?php else: foreach($sales_items as $item): ?>
                        <tr>
                            <td class="ps-4 fw-bold"><?= htmlspecialchars($item['table_name']) ?></td>
                            <td class="small text-white opacity-75"><?= htmlspecialchars($item['description']) ?></td>
                            <td class="text-end pe-4 fw-bold text-success">Rs. <?= number_format($item['amount'], 2) ?></td>
                        </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                    <tfoot class="border-top border-light border-opacity-10">
                        <tr class="bg-card">
                            <td colspan="2" class="text-end py-3 fw-bold text-dim">Grand Total</td>
                            <td class="text-end pe-4 py-3 fs-5 fw-bold text-primary">Rs. <?= number_format($total_sales, 2) ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="row g-5">
    <div class="col-md-6">
        <h5 class="fw-bold mb-4">Expense Breakdown</h5>
        <div class="d-flex flex-column gap-3">
             <div class="card p-3 bg-surface border-0 shadow-sm d-flex flex-row align-items-center justify-content-between">
                <div class="d-flex align-items-center">
                    <div class="bg-primary bg-opacity-10 p-2 rounded-3 me-3 text-primary">
                        <i class="fas fa-truck fa-sm"></i>
                    </div>
                    <div>
                        <div class="fw-bold small text-white">Logistics & Freight</div>
                        <div class="text-dim extra-small">Standard Delivery Fees</div>
                    </div>
                </div>
                <div class="fw-bold text-danger">Rs. 1,240.00</div>
            </div>
            <div class="card p-3 bg-surface border-0 shadow-sm d-flex flex-row align-items-center justify-content-between">
                <div class="d-flex align-items-center">
                    <div class="bg-primary bg-opacity-10 p-2 rounded-3 me-3 text-primary">
                        <i class="fas fa-bolt fa-sm"></i>
                    </div>
                    <div>
                        <div class="fw-bold small text-white">Utilities</div>
                        <div class="text-dim extra-small">Electricity & Water</div>
                    </div>
                </div>
                <div class="fw-bold text-danger">Rs. 850.00</div>
            </div>
            <div class="card p-3 bg-surface border-0 shadow-sm d-flex flex-row align-items-center justify-content-between">
                <div class="d-flex align-items-center">
                    <div class="bg-primary bg-opacity-10 p-2 rounded-3 me-3 text-primary">
                        <i class="fas fa-boxes-stacked fa-sm"></i>
                    </div>
                    <div>
                        <div class="fw-bold small text-white">Raw Material Procurement</div>
                        <div class="text-dim extra-small">Ad-hoc restock</div>
                    </div>
                </div>
                <div class="fw-bold text-danger">Rs. 1,030.00</div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="d-flex justify-content-between align-items-start mb-4">
            <h5 class="fw-bold mb-0">Labour & Staffing</h5>
            <div class="text-end">
                <div class="text-dim extra-small">TOTAL SHIFT HOURS</div>
                <div class="fw-bold text-white fs-5">336 hrs</div>
            </div>
        </div>
        <div class="card p-4 bg-surface border-0 shadow-sm">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <div class="text-dim extra-small">ACTIVE STAFF</div>
                <div class="fw-bold">42 Members</div>
            </div>
            
            <div class="mb-4">
                <div class="d-flex justify-content-between mb-2">
                    <span class="extra-small text-dim">Production Team</span>
                    <span class="extra-small fw-bold">Rs. 1,200.00</span>
                </div>
                <div class="progress bg-input" style="height: 6px;">
                    <div class="progress-bar bg-primary" style="width: 75%"></div>
                </div>
            </div>
            <div class="mb-4">
                <div class="d-flex justify-content-between mb-2">
                    <span class="extra-small text-dim">Maintenance & Security</span>
                    <span class="extra-small fw-bold">Rs. 450.00</span>
                </div>
                <div class="progress bg-input" style="height: 6px;">
                    <div class="progress-bar bg-warning" style="width: 45%"></div>
                </div>
            </div>
            <div class="mb-4">
                <div class="d-flex justify-content-between mb-2">
                    <span class="extra-small text-dim">Admin & Office Staff</span>
                    <span class="extra-small fw-bold">Rs. 200.00</span>
                </div>
                <div class="progress bg-input" style="height: 6px;">
                    <div class="progress-bar bg-success" style="width: 25%"></div>
                </div>
            </div>
            
            <div class="mt-4 pt-3 border-top border-light border-opacity-10 d-flex justify-content-between">
                <span class="text-dim small">Daily Labour Accrual</span>
                <span class="fw-bold text-white">Rs. 1,850.00</span>
            </div>
        </div>
    </div>
</div>

<div class="mt-5 pt-5 mb-5 px-5">
    <div class="card p-5 bg-card border-0 shadow-lg position-relative overflow-hidden">
        <div style="position: absolute; left: 0; top: 0; width: 4px; height: 100%; background: var(--primary);"></div>
        <h5 class="fw-bold mb-4">Chalan Confirmation</h5>
        <div class="row align-items-end">
            <div class="col-md-8">
                <p class="text-dim small mb-0 pe-5">I hereby certify that the above statement of accounts for the business day is accurate and verified against the physical inventory and ledger.</p>
            </div>
            <div class="col-md-4 text-center">
                <div class="mb-2" style="border-bottom: 1px solid var(--border); height: 40px; font-family: 'Dancing Script', cursive; font-size: 1.5rem; color: var(--text-dim);">Signature on file</div>
                <div class="extra-small text-dim fw-bold">AUTHORIZED SIGNATURE</div>
            </div>
        </div>
    </div>
</div>

    © <?= date('Y') ?> Business ERP Solutions. All Rights Reserved. Generated on <?= date('d M Y') ?>.
</div>

<style>
@media print {
    #sidebar, .no-print { display: none !important; }
    #content { margin-left: 0 !important; width: 100% !important; padding: 0 !important; }
    .card { border: 1px solid #ddd !important; }
}
</style>

<?php include 'includes/footer.php'; ?>
