  <?php
require_once 'config/database.php';

if (session_status() === PHP_SESSION_NONE) { session_start(); }
$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']);

// Ensure 'sales' table has 'table_name' column
try {
    $pdo->exec("ALTER TABLE sales ADD COLUMN table_name VARCHAR(255) DEFAULT 'Takeaway' AFTER id");
} catch (PDOException $e) { /* Column might already exist */ }

// Ensure 'cafe_tables' table exists
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS cafe_tables (
        id INT AUTO_INCREMENT PRIMARY KEY,
        table_name VARCHAR(255) UNIQUE NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Check if table is empty, if so, add some defaults
    $count = $pdo->query("SELECT COUNT(*) FROM cafe_tables")->fetchColumn();
    if ($count == 0) {
        $stmt = $pdo->prepare("INSERT INTO cafe_tables (table_name) VALUES (?)");
        $default_tables = ['Takeaway', 'Table 1', 'Table 2', 'Table 3', 'Table 4', 'Table 5', 'Table 6', 'Table 7', 'Table 8', 'Table 9', 'Table 10'];
        foreach ($default_tables as $tb) { $stmt->execute([$tb]); }
    }
} catch (PDOException $e) { /* Table probably exists */ }

// Ensure 'products' table exists
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        category VARCHAR(100),
        image_url VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Check if table is empty, if so, add some defaults
    $count = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    if ($count == 0) {
        $stmt = $pdo->prepare("INSERT INTO products (name, price, category) VALUES (?, ?, ?)");
        $items = [
            ['Karak Chai', 50.00, 'Tea'],
            ['Special Elaichi Chai', 70.00, 'Tea'],
            ['Coffee', 120.00, 'Beverages'],
            ['Samosa (2pc)', 80.00, 'Snacks'],
            ['Club Sandwich', 250.00, 'Food'],
            ['Patties', 60.00, 'Snacks'],
            ['Cold Coffee', 180.00, 'Beverages'],
            ['French Fries', 150.00, 'Snacks']
        ];
        foreach ($items as $item) { $stmt->execute($item); }
    }
} catch (PDOException $e) { /* Table probably exists */ }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_sale'])) {
    try {
        $sale_date   = $_POST['sale_date'];
        $amount      = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);
        $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_SPECIAL_CHARS);
        $table_name  = filter_input(INPUT_POST, 'table_name', FILTER_SANITIZE_SPECIAL_CHARS) ?: 'Takeaway';

        if ($sale_date && $amount) {
            $stmt = $pdo->prepare("INSERT INTO sales (sale_date, table_name, amount, description) VALUES (?, ?, ?, ?)");
            $stmt->execute([$sale_date, $table_name, $amount, $description]);
            $_SESSION['message'] = ['type' => 'success', 'text' => "Sale of Rs. " . number_format($amount, 2) . " for Table {$table_name} saved."];
        }
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    } catch (PDOException $e) {
        $_SESSION['message'] = ['type' => 'danger', 'text' => "Error: " . $e->getMessage()];
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}

// Add Table Logic
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_table'])) {
    $table_name = filter_input(INPUT_POST, 'table_name', FILTER_SANITIZE_SPECIAL_CHARS);
    try {
        $stmt = $pdo->prepare("INSERT INTO cafe_tables (table_name) VALUES (?)");
        $stmt->execute([$table_name]);
        $_SESSION['message'] = ['type' => 'success', 'text' => "Table '$table_name' added."];
    } catch (PDOException $e) {
        $_SESSION['message'] = ['type' => 'danger', 'text' => "Table already exists."];
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Delete Table Logic
if (isset($_GET['delete_table'])) {
    $id = $_GET['delete_table'];
    $pdo->prepare("DELETE FROM cafe_tables WHERE id = ? AND table_name != 'Takeaway'")->execute([$id]);
    $_SESSION['message'] = ['type' => 'success', 'text' => "Table removed."];
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Fetch Menu Items
$stmt = $pdo->query("SELECT * FROM products ORDER BY category, name");
$products = $stmt->fetchAll();
$categories = array_unique(array_column($products, 'category'));

// Fetch Tables
$stmt = $pdo->query("SELECT * FROM cafe_tables ORDER BY id ASC");
$tables = $stmt->fetchAll();

// Stats
$stmt = $pdo->query("SELECT SUM(amount) as total FROM sales WHERE sale_date = CURDATE()");
$today_total = $stmt->fetch()['total'] ?? 0;

$stmt = $pdo->query("SELECT COUNT(*) as count FROM sales WHERE sale_date = CURDATE()");
$today_count = $stmt->fetch()['count'] ?? 0;

$stmt = $pdo->query("SELECT * FROM sales ORDER BY sale_date DESC, created_at DESC LIMIT 5");
$recent_sales = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="mb-4 d-flex justify-content-between align-items-center">
    <div>
        <h2 class="fw-bold mb-1">Cafe POS</h2>
        <p class="text-dim small mb-0">Select items to create a bill or enter amount manually.</p>
    </div>
    <div class="d-flex gap-3">
        <div class="metric-mini p-2 px-3 rounded-pill bg-surface border border-light border-opacity-10 d-flex align-items-center">
            <span class="text-dim extra-small fw-bold me-2">TODAY:</span>
            <span class="text-success fw-bold">Rs. <?= number_format($today_total, 0) ?></span>
        </div>
        <button class="btn btn-outline-primary btn-sm rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#addManualSale">
            <i class="fas fa-keyboard me-1"></i> Manual Entry
        </button>
    </div>
</div>

<div class="row g-4">
    <!-- Menu Section (Left Side) -->
    <div class="col-lg-8">
        <!-- Tables Section -->
        <div class="mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h6 class="text-dim extra-small fw-bold mb-0 text-uppercase tracking-wider">Select Table / Space</h6>
                <button class="btn btn-sm btn-link text-primary text-decoration-none extra-small" data-bs-toggle="modal" data-bs-target="#manageTablesModal">
                    <i class="fas fa-edit me-1"></i>Manage Tables
                </button>
            </div>
            <div class="d-flex flex-wrap gap-2 mb-3">
                <?php foreach($tables as $idx => $t): ?>
                <button class="btn btn-outline-light border-opacity-10 rounded-3 px-3 table-btn <?= $idx === 0 ? 'active' : '' ?>" 
                        data-table="<?= htmlspecialchars($t['table_name']) ?>"
                        onclick="selectTable('<?= addslashes($t['table_name']) ?>', this)">
                    <?php if($t['table_name'] == 'Takeaway'): ?><i class="fas fa-walking me-2"></i><?php endif; ?>
                    <?= htmlspecialchars($t['table_name']) ?>
                    <span class="badge bg-danger ms-2 d-none cart-indicator"></span>
                </button>
                <?php endforeach; ?>
                <div class="input-group input-group-sm rounded-3 overflow-hidden border border-light border-opacity-10" style="width: 200px;">
                    <span class="input-group-text bg-surface border-0 text-dim"><i class="fas fa-edit"></i></span>
                    <input type="text" id="customTableName" class="form-control bg-surface border-0 text-white" placeholder="Custom" onkeyup="selectCustomTable(this.value)">
                </div>
            </div>
        </div>

        <div class="mb-4 d-flex gap-2 overflow-auto pb-2 no-scrollbar border-top border-light border-opacity-10 pt-4">
            <button class="btn btn-primary rounded-pill px-4 cat-btn active" onclick="filterMenu('all')">All Items</button>
            <?php foreach($categories as $cat): ?>
                <button class="btn btn-outline-light border-opacity-10 rounded-pill px-4 cat-btn" onclick="filterMenu('<?= $cat ?>')"><?= $cat ?></button>
            <?php endforeach; ?>
        </div>

        <div class="row g-3" id="menuGrid">
            <?php foreach($products as $p): ?>
            <div class="col-md-3 menu-item" data-category="<?= $p['category'] ?>">
                <div class="card p-3 h-100 product-card border-0 shadow-sm" onclick="addToCart(<?= $p['id'] ?>, '<?= addslashes($p['name']) ?>', <?= $p['price'] ?>)">
                    <div class="bg-primary bg-opacity-10 p-2 rounded-3 text-primary mb-3 d-flex justify-content-center">
                        <i class="fas <?= $p['category'] == 'Tea' ? 'fa-mug-hot' : ($p['category'] == 'Food' ? 'fa-hamburger' : 'fa-cookie-bite') ?> fa-lg"></i>
                    </div>
                    <div class="fw-bold text-white small mb-1"><?= htmlspecialchars($p['name']) ?></div>
                    <div class="text-success fw-bold">Rs. <?= number_format($p['price'], 0) ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Order Section (Right Side) -->
    <div class="col-lg-4">
        <div class="card p-4 h-100 d-flex flex-column border-0 shadow-lg" style="background: var(--bg-surface);">
            <h5 class="fw-bold mb-4 d-flex align-items-center justify-content-between">
                <span><i class="fas fa-shopping-basket text-primary me-2"></i> Current Order</span>
                <span class="badge bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25 fs-6 px-3 py-2 rounded-pill" id="orderTableName">Takeaway</span>
            </h5>
            
            <div id="cartItems" class="flex-grow-1 overflow-auto mb-4" style="min-height: 200px; max-height: 400px;">
                <div class="text-center text-dim py-5 mt-3">
                    <i class="fas fa-cart-plus fs-1 mb-3 opacity-25"></i>
                    <p>No items added yet</p>
                </div>
            </div>

            <div class="border-top border-light border-opacity-10 pt-4 mt-auto">
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-dim">Subtotal</span>
                    <span class="text-white" id="subtotal">Rs. 0</span>
                </div>
                <div class="d-flex justify-content-between mb-4 mt-1">
                    <span class="fw-bold fs-5">TOTAL</span>
                    <span class="fw-bold fs-5 text-success" id="totalDisplay">Rs. 0</span>
                </div>
                
                <form method="POST" id="checkoutForm">
                    <input type="hidden" name="amount" id="finalAmount">
                    <input type="hidden" name="description" id="finalDescription">
                    <input type="hidden" name="table_name" id="selectedTable" value="Takeaway">
                    <input type="hidden" name="sale_date" value="<?= date('Y-m-d') ?>">
                    <button type="submit" name="add_sale" class="btn btn-primary w-100 py-3 rounded-pill fw-bold fs-5 shadow-lg" id="checkoutBtn" disabled>
                        Finalize & Print
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Manage Tables Modal -->
<div class="modal fade" id="manageTablesModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-card border-0">
            <div class="modal-header border-light border-opacity-10">
                <h5 class="modal-title fw-bold">Table Management</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <form method="POST" class="mb-4">
                    <div class="row g-2">
                        <div class="col-8">
                            <input type="text" name="table_name" class="form-control" placeholder="New Table Name (e.g. Table 15)" required>
                        </div>
                        <div class="col-4">
                            <button type="submit" name="add_table" class="btn btn-primary w-100">Add Table</button>
                        </div>
                    </div>
                </form>
                
                <div class="table-responsive rounded-3 overflow-hidden border border-light border-opacity-10">
                    <table class="table table-dark mb-0">
                        <thead class="bg-surface">
                            <tr>
                                <th class="ps-3 small">Name</th>
                                <th class="text-end pe-3 small">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($tables as $t): ?>
                            <tr>
                                <td class="ps-3 fw-bold small"><?= htmlspecialchars($t['table_name']) ?></td>
                                <td class="text-end pe-3">
                                    <?php if($t['table_name'] != 'Takeaway'): ?>
                                    <a href="?delete_table=<?= $t['id'] ?>" class="text-danger" onclick="return confirm('Remove table?')"><i class="fas fa-trash"></i></a>
                                    <?php else: ?>
                                    <span class="text-dim extra-small">Default</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Manual Entry Modal -->
<div class="modal fade" id="addManualSale" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-card border-0">
            <form method="POST">
                <div class="modal-header border-light border-opacity-10">
                    <h5 class="modal-title fw-bold">Manual Sale Entry</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Description</label>
                        <input type="text" name="description" class="form-control" placeholder="e.g. Bulk Order" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Total Amount</label>
                        <input type="number" name="amount" class="form-control" step="0.01" required>
                    </div>
                    <input type="hidden" name="sale_date" value="<?= date('Y-m-d') ?>">
                </div>
                <div class="modal-footer border-0">
                    <button type="submit" name="add_sale" class="btn btn-primary w-100 rounded-pill">Save Sale</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.product-card {
    cursor: pointer;
    transition: all 0.2s;
}
.product-card:hover {
    transform: translateY(-5px);
    background: var(--primary-light);
    border: 1px solid var(--primary) !important;
}
.table-btn {
    transition: all 0.2s;
    font-size: 0.85rem;
}
.table-btn.active {
    background: var(--primary);
    color: white;
    border-color: var(--primary) !important;
}
.cart-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 0;
    border-bottom: 1px solid rgba(255,255,255,0.05);
}
.no-scrollbar::-webkit-scrollbar { display: none; }
</style>

<script>
// Use an object to store carts for each table
let carts = JSON.parse(localStorage.getItem('cafe_carts')) || {};
let currentTable = 'Takeaway';

function addToCart(id, name, price) {
    if (!carts[currentTable]) carts[currentTable] = [];
    
    const existing = carts[currentTable].find(i => i.id === id);
    if (existing) {
        existing.qty++;
    } else {
        carts[currentTable].push({id, name, price, qty: 1});
    }
    saveCarts();
    renderCart();
}

function removeFromCart(id) {
    if (!carts[currentTable]) return;
    const index = carts[currentTable].findIndex(i => i.id === id);
    if (index > -1) {
        if (carts[currentTable][index].qty > 1) carts[currentTable][index].qty--;
        else carts[currentTable].splice(index, 1);
    }
    saveCarts();
    renderCart();
}

function saveCarts() {
    localStorage.setItem('cafe_carts', JSON.stringify(carts));
    updateIndicators();
}

function updateIndicators() {
    document.querySelectorAll('.cart-indicator').forEach(el => el.classList.add('d-none'));
    for (const table in carts) {
        if (carts[table].length > 0) {
            const btn = document.querySelector(`.table-btn[data-table="${table}"]`);
            if(btn) {
                const indicator = btn.querySelector('.cart-indicator');
                if(indicator) {
                    indicator.classList.remove('d-none');
                    indicator.innerText = carts[table].length;
                }
            }
        }
    }
}

function renderCart() {
    const list = document.getElementById('cartItems');
    const totalDisplay = document.getElementById('totalDisplay');
    const subtotalDisplay = document.getElementById('subtotal');
    const finalAmount = document.getElementById('finalAmount');
    const finalDesc = document.getElementById('finalDescription');
    const checkoutBtn = document.getElementById('checkoutBtn');
    
    const currentCart = carts[currentTable] || [];

    if (currentCart.length === 0) {
        list.innerHTML = `<div class="text-center text-dim py-5 mt-3"><i class="fas fa-cart-plus fs-1 mb-3 opacity-25"></i><p>No items added for ${currentTable}</p></div>`;
        totalDisplay.innerText = 'Rs. 0';
        subtotalDisplay.innerText = 'Rs. 0';
        checkoutBtn.disabled = true;
        return;
    }

    let total = 0;
    let desc = `Order (${currentTable}): `;
    list.innerHTML = '';
    
    currentCart.forEach(item => {
        total += item.price * item.qty;
        desc += `${item.name} x${item.qty}, `;
        list.innerHTML += `
            <div class="cart-item">
                <div class="flex-grow-1">
                    <div class="fw-bold small text-white">${item.name}</div>
                    <div class="text-dim extra-small">Rs. ${item.price} x ${item.qty}</div>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <div class="fw-bold text-success me-2">Rs. ${(item.price * item.qty).toLocaleString()}</div>
                    <button class="btn btn-sm btn-link text-danger p-0" onclick="removeFromCart(${item.id})"><i class="fas fa-minus-circle"></i></button>
                </div>
            </div>
        `;
    });

    totalDisplay.innerText = `Rs. ${total.toLocaleString()}`;
    subtotalDisplay.innerText = `Rs. ${total.toLocaleString()}`;
    finalAmount.value = total;
    finalDesc.value = desc.slice(0, -2);
    checkoutBtn.disabled = false;
}

// Initial render
updateIndicators();
renderCart();

function filterMenu(category) {
    const buttons = document.querySelectorAll('.cat-btn');
    buttons.forEach(b => b.classList.remove('btn-primary', 'active'));
    buttons.forEach(b => {
        if(b.innerText === category || (category === 'all' && b.innerText === 'All Items')) {
            b.classList.add('btn-primary', 'active');
        }
    });

    const items = document.querySelectorAll('.menu-item');
    items.forEach(item => {
        if (category === 'all' || item.getAttribute('data-category') === category) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

function selectTable(name, el) {
    currentTable = name;
    document.getElementById('selectedTable').value = name;
    document.getElementById('orderTableName').innerText = name;
    document.querySelectorAll('.table-btn').forEach(b => b.classList.remove('active'));
    if(el) el.classList.add('active');
    document.getElementById('customTableName').value = '';
    renderCart();
}

function selectCustomTable(val) {
    if(val.trim() !== '') {
        currentTable = val;
        document.getElementById('selectedTable').value = val;
        document.getElementById('orderTableName').innerText = val;
        document.querySelectorAll('.table-btn').forEach(b => b.classList.remove('active'));
        renderCart();
    } else {
        selectTable('Takeaway', document.querySelector('.table-btn'));
    }
}

// Clear cart for current table after successful checkout
document.getElementById('checkoutForm').addEventListener('submit', function() {
    delete carts[currentTable];
    saveCarts();
});
</script>

<?php include 'includes/footer.php'; ?>
