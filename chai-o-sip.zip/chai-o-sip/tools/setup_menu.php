<?php
require_once '../config/database.php';

echo "<h2>Setting up Cafe Menu System...</h2>";

try {
    // 1. Create products table if it doesn't exist
    $pdo->exec("CREATE TABLE IF NOT EXISTS products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        category VARCHAR(100),
        image_url VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    
    // 2. Insert some default Cafe items if the table is empty
    $count = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    if ($count == 0) {
        $stmt = $pdo->prepare("INSERT INTO products (name, price, category) VALUES (?, ?, ?)");
        $items = [
            ['Karak Chai', 50.00, 'Tea'],
            ['Special Elaichi Chai', 70.00, 'Tea'],
            ['Coffee', 120.00, 'Beverages'],
            ['Samosa (2pc)', 80.00, 'Snacks'],
            ['Club Sandwich', 250.00, 'Food'],
            ['Patties', 60.00, 'Snacks'],
            ['Cold Coffee', 180.00, 'Beverages'],
            ['French Fries', 150.00, 'Snacks']
        ];
        foreach ($items as $item) {
            $stmt->execute($item);
        }
        echo "Default Cafe items added to menu.<br>";
    }

    echo "<br><h3 style='color: green;'>Success! Menu system is ready.</h3>";
    echo "<a href='../sales.php'>Go to Sales Page</a>";

} catch (Exception $e) {
    echo "<br><h3 style='color: red;'>Error: " . $e->getMessage() . "</h3>";
}
?>
