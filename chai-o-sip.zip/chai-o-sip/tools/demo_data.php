<?php
require_once '../config/database.php';

echo "<h2>Starting Demo Data Generation...</h2>";

try {
    // 1. Clear existing data (optional, but good for a fresh start)
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0;");
    $pdo->exec("TRUNCATE TABLE sales;");
    $pdo->exec("TRUNCATE TABLE expenses;");
    $pdo->exec("TRUNCATE TABLE labour_ledger;");
    $pdo->exec("TRUNCATE TABLE labour;");
    $pdo->exec("TRUNCATE TABLE inventory;");
    $pdo->exec("TRUNCATE TABLE vendor_payments;");
    $pdo->exec("TRUNCATE TABLE vendor_invoices;");
    $pdo->exec("TRUNCATE TABLE vendors;");
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1;");
    echo "Existing data cleared.<br>";

    // 2. Add Vendors
    $stmt = $pdo->prepare("INSERT INTO vendors (name, contact_info) VALUES (?, ?)");
    $stmt->execute(['Tea Leaf Co.', 'Bulk tea suppliers - 9876543210']);
    $stmt->execute(['Dairy Fresh', 'Milk and cream delivery - 1234567890']);
    $vendor_ids = $pdo->query("SELECT id FROM vendors")->fetchAll(PDO::FETCH_COLUMN);
    echo "Vendors added.<br>";

    // 3. Add Inventory
    $stmt = $pdo->prepare("INSERT INTO inventory (item_name, total_received, total_used, min_threshold) VALUES (?, ?, ?, ?)");
    $stmt->execute(['Tea Dust (kg)', 50, 46, 5]); // Low stock alert trigger
    $stmt->execute(['Sugar (kg)', 100, 20, 10]);
    $stmt->execute(['Milk Packets', 200, 150, 20]);
    echo "Inventory items added (including a low stock alert).<br>";

    // 4. Add Labour
    $stmt = $pdo->prepare("INSERT INTO labour (name, monthly_salary) VALUES (?, ?)");
    $stmt->execute(['Rahul Sharma', 15000]);
    $stmt->execute(['Amit Kumar', 12000]);
    $labour_ids = $pdo->query("SELECT id FROM labour")->fetchAll(PDO::FETCH_COLUMN);
    echo "Labour staff added.<br>";

    // 5. Add Sales (Last 30 days)
    $stmt = $pdo->prepare("INSERT INTO sales (sale_date, amount, description) VALUES (?, ?, ?)");
    for ($i = 0; $i < 30; $i++) {
        $date = date('Y-m-d', strtotime("-$i days"));
        $amount = rand(1500, 3500);
        $stmt->execute([$date, $amount, "Daily counter sales"]);
    }
    echo "30 days of sales data generated.<br>";

    // 6. Add Expenses
    $stmt = $pdo->prepare("INSERT INTO expenses (expense_date, category, amount, description) VALUES (?, ?, ?, ?)");
    $stmt->execute([date('Y-m-d'), 'Daily', 150, 'Daily tea/snacks for staff']);
    $stmt->execute([date('Y-m-d', strtotime("-1 day")), 'Out-Expense', 1200, 'Electrician repair']);
    $stmt->execute([date('Y-m-d', strtotime("-5 days")), 'Daily', 50, 'Cleaning supplies']);
    echo "Expenses added.<br>";

    // 7. Add Labour Ledger
    $stmt = $pdo->prepare("INSERT INTO labour_ledger (labour_id, payment_date, amount, type, description) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$labour_ids[0], date('Y-m-d', strtotime("-10 days")), 2000, 'Advance', 'Personal emergency']);
    $stmt->execute([$labour_ids[1], date('Y-m-d', strtotime("-2 days")), 12000, 'Salary Payment', 'Full salary for Jan']);
    echo "Labour ledger entries added.<br>";

    // 8. Vendor Invoices & Payments
    $stmt_inv = $pdo->prepare("INSERT INTO vendor_invoices (vendor_id, invoice_date, invoice_number, amount) VALUES (?, ?, ?, ?)");
    $stmt_pay = $pdo->prepare("INSERT INTO vendor_payments (vendor_id, payment_date, amount, reference) VALUES (?, ?, ?, ?)");
    
    $stmt_inv->execute([$vendor_ids[0], date('Y-m-d', strtotime("-15 days")), 'INV-001', 5000]);
    $stmt_pay->execute([$vendor_ids[0], date('Y-m-d', strtotime("-5 days")), 3500, 'UTR-123456']);
    
    $stmt_inv->execute([$vendor_ids[1], date('Y-m-d', strtotime("-10 days")), 'INV-002', 2000]);
    echo "Vendor transactions added (remaining balance generated).<br>";

    echo "<br><h3 style='color: green;'>Success! Demo data has been generated.</h3>";
    echo "<a href='../index.php'>Go to Dashboard</a>";

} catch (Exception $e) {
    echo "<br><h3 style='color: red;'>Error: " . $e->getMessage() . "</h3>";
}
?>
