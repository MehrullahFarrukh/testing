<?php
require_once 'config/database.php';

if (session_status() === PHP_SESSION_NONE) { session_start(); }
$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']);

// Ensure 'products' table exists (Silent check)
try { $pdo->exec("CREATE TABLE IF NOT EXISTS products (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, price DECIMAL(10,2) NOT NULL, category VARCHAR(100), image_url VARCHAR(255), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)"); } catch (PDOException $e) {}

// Add Item
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_SPECIAL_CHARS);
    $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
    $category = filter_input(INPUT_POST, 'category', FILTER_SANITIZE_SPECIAL_CHARS);
    
    $stmt = $pdo->prepare("INSERT INTO products (name, price, category) VALUES (?, ?, ?)");
    $stmt->execute([$name, $price, $category]);
    $_SESSION['message'] = ['type' => 'success', 'text' => "Item '$name' added to menu."];
    header("Location: menu.php");
    exit;
}

// Delete Item
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$id]);
    $_SESSION['message'] = ['type' => 'success', 'text' => "Item removed from menu."];
    header("Location: menu.php");
    exit;
}

$stmt = $pdo->query("SELECT * FROM products ORDER BY category, name");
$products = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="mb-4 d-flex justify-content-between align-items-center">
    <div>
        <h2 class="fw-bold mb-1">Menu Manager</h2>
        <p class="text-dim small mb-0">Add or remove items from your cafe menu.</p>
    </div>
    <button class="btn btn-primary rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#addItemModal">
        <i class="fas fa-plus me-2"></i> Add Menu Item
    </button>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card p-0 border-0 shadow-sm overflow-hidden">
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4">Item Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($products as $p): ?>
                        <tr>
                            <td class="ps-4">
                                <div class="d-flex align-items-center">
                                    <div class="bg-primary bg-opacity-10 p-2 rounded-3 text-primary me-3">
                                        <i class="fas fa-mug-hot"></i>
                                    </div>
                                    <span class="fw-bold"><?= htmlspecialchars($p['name']) ?></span>
                                </div>
                            </td>
                            <td><span class="badge bg-input text-dim border border-light border-opacity-10"><?= htmlspecialchars($p['category']) ?></span></td>
                            <td class="fw-bold text-success">Rs. <?= number_format($p['price'], 2) ?></td>
                            <td class="text-end pe-4">
                                <a href="?delete=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger border-0" onclick="return confirm('Remove this item?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($products)): ?>
                        <tr>
                            <td colspan="4" class="text-center py-5 text-dim">No items in menu yet.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Item Modal -->
<div class="modal fade" id="addItemModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-card border-0 shadow-lg">
            <form method="POST">
                <div class="modal-header border-light border-opacity-10">
                    <h5 class="modal-title fw-bold">Add New Menu Item</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Item Name</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Masala Chai" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Category</label>
                        <select name="category" class="form-select" required>
                            <option value="Tea">Tea</option>
                            <option value="Beverages">Beverages</option>
                            <option value="Snacks">Snacks</option>
                            <option value="Food">Food</option>
                            <option value="Desserts">Desserts</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Price (Rs.)</label>
                        <input type="number" step="0.01" name="price" class="form-control" placeholder="0.00" required>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="submit" name="add_product" class="btn btn-primary w-100 rounded-pill py-3 fw-bold">Save to Menu</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
