<?php
require_once 'config/database.php';

$vendor_id = $_GET['id'] ?? null;
if (!$vendor_id) { header("Location: vendors.php"); exit; }

$stmt = $pdo->prepare("SELECT * FROM vendors WHERE id = ?");
$stmt->execute([$vendor_id]);
$vendor = $stmt->fetch();
if (!$vendor) { header("Location: vendors.php"); exit; }

if (session_status() === PHP_SESSION_NONE) { session_start(); }
$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_invoice'])) {
        $stmt = $pdo->prepare("INSERT INTO vendor_invoices (vendor_id, invoice_date, invoice_number, amount) VALUES (?, ?, ?, ?)");
        $stmt->execute([$vendor_id, $_POST['invoice_date'], $_POST['invoice_number'], $_POST['amount']]);
        $_SESSION['message'] = ['type' => 'success', 'text' => "Invoice #{$_POST['invoice_number']} added."];
    } elseif (isset($_POST['add_payment'])) {
        $stmt = $pdo->prepare("INSERT INTO vendor_payments (vendor_id, payment_date, amount, reference) VALUES (?, ?, ?, ?)");
        $stmt->execute([$vendor_id, $_POST['payment_date'], $_POST['amount'], $_POST['reference']]);
        $_SESSION['message'] = ['type' => 'success', 'text' => "Payment of Rs. {$_POST['amount']} recorded."];
    }
    header("Location: vendor_details.php?id=$vendor_id");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM vendor_invoices WHERE vendor_id = ? ORDER BY invoice_date DESC");
$stmt->execute([$vendor_id]);
$invoices = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM vendor_payments WHERE vendor_id = ? ORDER BY payment_date DESC");
$stmt->execute([$vendor_id]);
$payments = $stmt->fetchAll();

$total_inv = array_sum(array_column($invoices, 'amount'));
$total_paid = array_sum(array_column($payments, 'amount'));
$balance = $total_inv - $total_paid;

include 'includes/header.php';
?>

<div class="mb-4 d-flex justify-content-between align-items-center">
    <div>
        <h2 class="fw-bold mb-1"><?= htmlspecialchars($vendor['name']) ?></h2>
        <p class="text-dim small mb-0">Vendor Ledger & Transaction History</p>
    </div>
    <a href="vendors.php" class="btn btn-outline-light border-opacity-10 rounded-pill px-4 small">
        <i class="fas fa-arrow-left me-2"></i> Back to Directory
    </a>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="card p-4 h-100 border-0 shadow-sm" style="background: var(--bg-surface);">
            <div class="text-dim extra-small mb-1" style="font-size: 0.65rem;">Total Liabilities</div>
            <div class="fw-bold fs-4 text-white">Rs. <?= number_format($total_inv, 2) ?></div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card p-4 h-100 border-0 shadow-sm" style="background: var(--bg-surface);">
            <div class="text-dim extra-small mb-1" style="font-size: 0.65rem;">Total Cleared</div>
            <div class="fw-bold fs-4 text-success">Rs. <?= number_format($total_paid, 2) ?></div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card p-4 h-100 border-0 shadow-sm border-start border-danger border-4" style="background: var(--bg-surface);">
            <div class="text-dim extra-small mb-1" style="font-size: 0.65rem;">Outstanding Balance</div>
            <div class="fw-bold fs-4 text-danger">Rs. <?= number_format($balance, 2) ?></div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Invoices -->
    <div class="col-lg-6">
        <div class="card p-0 border-0 shadow-sm overflow-hidden h-100">
            <div class="px-4 py-3 border-bottom border-light border-opacity-10 d-flex justify-content-between align-items-center">
                <h6 class="mb-0 fw-bold">Purchase Invoices</h6>
                <button class="btn btn-primary btn-sm rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#invoiceModal">
                    <i class="fas fa-plus me-1"></i> Add
                </button>
            </div>
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4">Date</th>
                            <th>Invoice #</th>
                            <th class="text-end pe-4">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($invoices as $inv): ?>
                        <tr>
                            <td class="ps-4 text-dim small"><?= date('d M, Y', strtotime($inv['invoice_date'])) ?></td>
                            <td class="text-white fw-bold"><?= htmlspecialchars($inv['invoice_number']) ?></td>
                            <td class="text-end pe-4 fw-bold">Rs. <?= number_format($inv['amount'], 2) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Payments -->
    <div class="col-lg-6">
        <div class="card p-0 border-0 shadow-sm overflow-hidden h-100">
            <div class="px-4 py-3 border-bottom border-light border-opacity-10 d-flex justify-content-between align-items-center">
                <h6 class="mb-0 fw-bold">Payment History</h6>
                <button class="btn btn-success btn-sm rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#paymentModal">
                    <i class="fas fa-plus me-1"></i> Pay
                </button>
            </div>
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4">Date</th>
                            <th>Reference</th>
                            <th class="text-end pe-4">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($payments as $pay): ?>
                        <tr>
                            <td class="ps-4 text-dim small"><?= date('d M, Y', strtotime($pay['payment_date'])) ?></td>
                            <td class="text-white fw-bold"><?= htmlspecialchars($pay['reference']) ?></td>
                            <td class="text-end pe-4 fw-bold text-success">Rs. <?= number_format($pay['amount'], 2) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modals -->
<div class="modal fade" id="invoiceModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-card border-0 shadow-lg">
            <form method="POST">
                <div class="modal-header border-light border-opacity-10">
                    <h5 class="modal-title fw-bold">New Bill</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Invoice Date</label>
                        <input type="date" name="invoice_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Invoice Number</label>
                        <input type="text" name="invoice_number" class="form-control" placeholder="INV-2024-XXX" required>
                    </div>
                    <div class="mb-0">
                        <label class="form-label small fw-bold">Bill Amount (Rs.)</label>
                        <input type="number" step="0.01" name="amount" class="form-control" placeholder="0.00" required>
                    </div>
                </div>
                <div class="modal-footer border-0 p-3">
                    <button type="submit" name="add_invoice" class="btn btn-primary w-100 rounded-pill">Post Invoice</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="paymentModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-card border-0 shadow-lg">
            <form method="POST">
                <div class="modal-header border-light border-opacity-10">
                    <h5 class="modal-title fw-bold">Record Payment</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Payment Date</label>
                        <input type="date" name="payment_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Reference (UTR/Cheque)</label>
                        <input type="text" name="reference" class="form-control" placeholder="HDFCR52024..." required>
                    </div>
                    <div class="mb-0">
                        <label class="form-label small fw-bold">Amount Paid (Rs.)</label>
                        <input type="number" step="0.01" name="amount" class="form-control" placeholder="0.00" required>
                    </div>
                </div>
                <div class="modal-footer border-0 p-3">
                    <button type="submit" name="add_payment" class="btn btn-success w-100 rounded-pill">Confirm Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
