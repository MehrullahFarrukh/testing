<?php
require_once 'config/database.php';

if (session_status() === PHP_SESSION_NONE) { session_start(); }
$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_labour'])) {
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_SPECIAL_CHARS);
    $salary = filter_input(INPUT_POST, 'monthly_salary', FILTER_VALIDATE_FLOAT);

    if ($name && $salary) {
        $stmt = $pdo->prepare("INSERT INTO labour (name, monthly_salary) VALUES (?, ?)");
        $stmt->execute([$name, $salary]);
        $_SESSION['message'] = ['type' => 'success', 'text' => "Staff member '{$name}' added to payroll."];
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

$stmt = $pdo->query("SELECT * FROM labour ORDER BY name ASC");
$labourers = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="mb-4 d-flex justify-content-between align-items-center">
    <div>
        <h2 class="fw-bold mb-1">Staff List</h2>
        <p class="text-dim small mb-0">Manage your employees, their monthly salaries, and work records.</p>
    </div>
    <button class="btn btn-primary px-4 rounded-pill shadow-sm" data-bs-toggle="modal" data-bs-target="#addLabourModal">
        <i class="fas fa-user-plus me-2"></i> Add Staff
    </button>
</div>

<div class="row g-4">
    <?php foreach ($labourers as $l): ?>
    <div class="col-md-4">
        <div class="card p-4 h-100 border-0 shadow-sm hover-up" style="background: var(--bg-surface); transition: transform 0.3s ease;">
            <div class="d-flex justify-content-between align-items-start mb-4">
                <div class="bg-primary bg-opacity-10 p-3 rounded-4 text-primary">
                    <i class="fas fa-user-tie fa-lg"></i>
                </div>
                <span class="badge-pill trend-up" style="font-size: 0.65rem;">Active Status</span>
            </div>
            
            <h5 class="fw-bold mb-1 text-white"><?= htmlspecialchars($l['name']) ?></h5>
            <p class="text-dim small mb-4">Operations & Management Team</p>
            
            <div class="mb-4">
                <div class="text-dim extra-small" style="font-size: 0.65rem;">Monthly Salary</div>
                <div class="fw-bold text-white fs-4">Rs. <?= number_format($l['monthly_salary'], 2) ?></div>
            </div>
            
            <div class="mt-auto pt-3 border-top border-light border-opacity-10 d-flex justify-content-between align-items-center">
                <a href="labour_ledger.php?id=<?= $l['id'] ?>" class="btn btn-link text-primary text-decoration-none small fw-bold p-0">
                    Payment History <i class="fas fa-arrow-right ms-1" style="font-size: 0.7rem;"></i>
                </a>
                <div class="d-flex gap-2">
                    <div class="bg-card p-2 rounded-circle text-dim" style="width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-envelope fa-xs"></i>
                    </div>
                    <div class="bg-card p-2 rounded-circle text-dim" style="width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;">
                        <i class="fas fa-phone fa-xs"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    
    <?php if (empty($labourers)): ?>
    <div class="col-12">
        <div class="card text-center p-5 bg-surface border-dashed">
            <i class="fas fa-users-slash text-dim fs-1 mb-3"></i>
            <h5 class="text-dim">No staff members registered yet.</h5>
            <p class="text-dim small mb-4">Add your first employee to start tracking salaries.</p>
            <button class="btn btn-primary d-inline-block rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#addLabourModal">Add First Employee</button>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Add Labour Modal -->
<div class="modal fade" id="addLabourModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-card border-0 shadow-lg">
            <form method="POST">
                <div class="modal-header border-light border-opacity-10 p-4">
                    <h5 class="modal-title fw-bold">Add Staff Member</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Full Name</label>
                        <input type="text" name="name" class="form-control py-3" placeholder="e.g. Ali Ahmed" required>
                    </div>
                    <div class="mb-4">
                        <label class="form-label small fw-bold">Monthly Salary</label>
                        <div class="search-bar w-100 py-2 px-3 bg-input">
                            <i class="fas fa-wallet text-dim"></i>
                            <input type="number" step="0.01" name="monthly_salary" class="bg-transparent border-0 text-white w-100" placeholder="0.00" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="submit" name="add_labour" class="btn btn-primary w-100 rounded-pill py-3 fw-bold shadow-lg">Save Staff</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.hover-up:hover {
    transform: translateY(-8px);
    box-shadow: 0 12px 24px rgba(0,0,0,0.3) !important;
}
.border-dashed {
    border: 2px dashed rgba(255,255,255,0.05) !important;
}
</style>

<?php include 'includes/footer.php'; ?>
