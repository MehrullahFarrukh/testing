<?php
require_once 'config/database.php';

if (session_status() === PHP_SESSION_NONE) { session_start(); }
$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_expense'])) {
        $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_SPECIAL_CHARS);
        $category = $_POST['category'];
        $amount = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);
        $date = $_POST['expense_date'];
        $method = $_POST['payment_method'];
        $notes = filter_input(INPUT_POST, 'notes', FILTER_SANITIZE_SPECIAL_CHARS);
        
        if ($title && $amount > 0) {
            $stmt = $pdo->prepare("INSERT INTO expenses (title, category, amount, payment_method, expense_date, description) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$title, $category, $amount, $method, $date, $notes]);
            $_SESSION['message'] = ['type' => 'success', 'text' => "Expense of Rs. " . number_format($amount, 2) . " recorded."];
        }
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

$stmt = $pdo->query("SELECT * FROM expenses ORDER BY expense_date DESC, created_at DESC LIMIT 3");
$recent_expenses = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="mb-4 d-flex justify-content-between align-items-end">
    <div>
        <h2 class="fw-bold mb-1">Add Expense</h2>
        <p class="text-dim small mb-0">Record your daily costs and bills to track your spending.</p>
    </div>
    <div class="ms-auto d-flex align-items-center gap-4 no-print">
        <i class="far fa-bell text-dim fs-5"></i>
        <div class="text-dim small"><?= date('M d, Y') ?></div>
    </div>
</div>

<div class="row g-4 mb-5">
    <div class="col-lg-12">
        <div class="card p-5 border-0 shadow-lg" style="max-width: 900px; margin: 0 auto; background: var(--bg-surface);">
            <form method="POST">
                <div class="mb-4">
                    <label class="form-label small fw-bold">What was the expense?</label>
                    <div class="search-bar w-100 py-2 px-3 bg-input">
                        <i class="fas fa-align-left text-dim"></i>
                        <input type="text" name="title" class="bg-transparent border-0 text-white w-100" placeholder="e.g., Milk, Sugar, Electricity Bill" required>
                    </div>
                </div>

                <div class="row g-4 mb-4">
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Category</label>
                        <select name="category" class="form-select py-3 border-0 bg-input shadow-none text-white">
                            <option value="Daily">Daily Shop Costs</option>
                            <option value="Out-Expense">External Payments</option>
                            <option value="Utilities">Electricity/Water/Bills</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Amount (Rs.)</label>
                        <input type="number" step="0.01" name="amount" class="form-control py-3 border-0 bg-input shadow-none text-white" placeholder="0.00" required>
                    </div>
                </div>

                <div class="row g-4 mb-4">
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Date</label>
                        <input type="date" name="expense_date" class="form-control py-3 border-0 bg-input shadow-none text-white" value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Payment Method</label>
                        <div class="d-flex gap-2">
                             <input type="radio" class="btn-check" name="payment_method" id="pay1" value="Cash" checked>
                             <label class="btn btn-outline-light border-opacity-10 py-3 flex-fill" for="pay1">Cash</label>
                             
                             <input type="radio" class="btn-check" name="payment_method" id="pay2" value="Card">
                             <label class="btn btn-outline-light border-opacity-10 py-3 flex-fill" for="pay2">Card</label>
                             
                             <input type="radio" class="btn-check" name="payment_method" id="pay3" value="Transfer">
                             <label class="btn btn-outline-light border-opacity-10 py-3 flex-fill" for="pay3">Transfer</label>
                        </div>
                    </div>
                </div>

                <div class="mb-5">
                    <label class="form-label small fw-bold">Additional Notes (Optional)</label>
                    <textarea name="notes" class="form-control border-0 bg-input shadow-none p-4 text-white" rows="4" placeholder="Details about the transaction..."></textarea>
                </div>

                <div class="d-flex align-items-center justify-content-between">
                    <button type="reset" class="btn btn-link text-dim text-decoration-none small fw-bold p-0">Clear Form</button>
                    <button type="submit" name="add_expense" class="btn btn-primary px-5 py-3 rounded-pill shadow">
                        <i class="fas fa-paper-plane me-2"></i> Save Expense
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h5 class="fw-bold mb-0">Last Few Expenses</h5>
    <a href="#" class="text-primary small text-decoration-none fw-bold">View All <i class="fas fa-arrow-right ms-1"></i></a>
</div>

<div class="row g-4">
    <?php foreach($recent_expenses as $exp): 
        $icon = 'fa-gas-pump';
        if(stripos($exp['title'], 'printer') !== false || stripos($exp['title'], 'ink') !== false) $icon = 'fa-print';
        if(stripos($exp['category'], 'Out') !== false) $icon = 'fa-shopping-cart';
    ?>
    <div class="col-md-4">
        <div class="card p-4 h-100 bg-surface border-0 shadow-sm shadow-highlight">
            <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="bg-primary bg-opacity-10 p-3 rounded-3 text-primary">
                    <i class="fas <?= $icon ?> fa-lg"></i>
                </div>
                <div class="text-dim small fw-bold"><?= date('Y-m-d', strtotime($exp['expense_date'])) == date('Y-m-d') ? 'TODAY' : 'YESTERDAY' ?></div>
            </div>
            <h6 class="fw-bold mb-1 text-white"><?= htmlspecialchars($exp['title']) ?></h6>
            <div class="fs-4 fw-bold mb-3 text-white">Rs.<?= number_format($exp['amount'], 2) ?></div>
            <div class="text-dim small mt-auto">Paid via <?= htmlspecialchars($exp['payment_method']) ?></div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<style>
.shadow-highlight:hover {
    box-shadow: 0 10px 30px rgba(0,0,0,0.5), 0 0 20px rgba(37, 99, 235, 0.1) !important;
    transform: translateY(-5px);
    transition: all 0.3s ease;
}
</style>

<?php include 'includes/footer.php'; ?>
