<?php
require_once 'config/database.php';

$labour_id = $_GET['id'] ?? null;
if (!$labour_id) { header("Location: labour.php"); exit; }

$stmt = $pdo->prepare("SELECT * FROM labour WHERE id = ?");
$stmt->execute([$labour_id]);
$labour = $stmt->fetch();
if (!$labour) { header("Location: labour.php"); exit; }

if (session_status() === PHP_SESSION_NONE) { session_start(); }
$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_entry'])) {
    $payment_date = $_POST['payment_date'];
    $amount = $_POST['amount'];
    $type = $_POST['type'];
    $description = $_POST['description'];

    $stmt = $pdo->prepare("INSERT INTO labour_ledger (labour_id, payment_date, amount, type, description) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$labour_id, $payment_date, $amount, $type, $description]);
    $_SESSION['message'] = ['type' => 'success', 'text' => "Recorded $type of Rs. $amount"];
    header("Location: labour_ledger.php?id=$labour_id");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM labour_ledger WHERE labour_id = ? ORDER BY payment_date DESC");
$stmt->execute([$labour_id]);
$entries = $stmt->fetchAll();

$total_paid = 0; $total_advances = 0;
foreach ($entries as $e) {
    if ($e['type'] == 'Salary Payment') $total_paid += $e['amount'];
    else $total_advances += $e['amount'];
}

include 'includes/header.php';
?>

<div class="mb-4 d-flex justify-content-between align-items-center">
    <div>
        <h2 class="fw-bold mb-1"><?= htmlspecialchars($labour['name']) ?></h2>
        <p class="text-dim small mb-0">Staff Payment Record</p>
    </div>
    <a href="labour.php" class="btn btn-outline-light border-opacity-10 rounded-pill px-4 small">
        <i class="fas fa-arrow-left me-2"></i> Go Back to Staff
    </a>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="card p-4 h-100 border-0 shadow-sm" style="background: var(--bg-surface);">
            <div class="text-dim extra-small mb-1" style="font-size: 0.65rem;">Monthly Salary</div>
            <div class="fw-bold fs-4 text-white">Rs. <?= number_format($labour['monthly_salary'], 2) ?></div>
            <div class="text-dim extra-small mt-1">Agreed Monthly Salary</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card p-4 h-100 border-0 shadow-sm" style="background: var(--bg-surface);">
            <div class="text-dim extra-small mb-1" style="font-size: 0.65rem;">Total Paid</div>
            <div class="fw-bold fs-4 text-success">Rs. <?= number_format($total_paid, 2) ?></div>
            <div class="text-dim extra-small mt-1">Total amount already paid</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card p-4 h-100 border-0 shadow-sm border-start border-warning border-4" style="background: var(--bg-surface);">
            <div class="text-dim extra-small mb-1" style="font-size: 0.65rem;">Advances Given</div>
            <div class="fw-bold fs-4 text-warning">Rs. <?= number_format($total_advances, 2) ?></div>
            <div class="text-dim extra-small mt-1">Amount to be cut from next salary</div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Entry Form -->
    <div class="col-lg-4">
        <div class="card p-4 border-0 shadow-sm" style="background: var(--bg-surface);">
            <h5 class="fw-bold mb-4">New Entry</h5>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label small fw-bold">Date</label>
                    <input type="date" name="payment_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold">Payment Type</label>
                    <select name="type" class="form-select bg-input border-0 text-white" required>
                        <option value="Salary Payment">Full Salary</option>
                        <option value="Advance">Advance Given</option>
                        <option value="Other Expense">Other</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold">Amount (Rs.)</label>
                    <input type="number" step="0.01" name="amount" class="form-control" placeholder="0.00" required>
                </div>
                <div class="mb-4">
                    <label class="form-label small fw-bold">Notes</label>
                    <textarea name="description" class="form-control" rows="2" placeholder="Note on payment..."></textarea>
                </div>
                <button type="submit" name="add_entry" class="btn btn-primary w-100 py-3 rounded-pill shadow-lg fw-bold">
                    <i class="fas fa-receipt me-2"></i> Save Payment
                </button>
            </form>
        </div>
    </div>

    <!-- Ledger Table -->
    <div class="col-lg-8">
        <div class="card p-0 border-0 shadow-sm h-100 overflow-hidden">
            <div class="px-4 py-3 border-bottom border-light border-opacity-10">
                <h6 class="mb-0 fw-bold">Payment History</h6>
            </div>
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4">Date</th>
                            <th>Type</th>
                            <th>Description</th>
                            <th class="text-end pe-4">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($entries as $e): ?>
                        <tr>
                            <td class="ps-4 text-dim small"><?= date('d M, Y', strtotime($e['payment_date'])) ?></td>
                            <td>
                                <span class="badge-pill <?= $e['type'] == 'Salary Payment' ? 'trend-up' : 'trend-down' ?>" style="font-size: 0.65rem;">
                                    <?= $e['type'] ?>
                                </span>
                            </td>
                            <td class="text-white small"><?= htmlspecialchars($e['description']) ?></td>
                            <td class="text-end pe-4 fw-bold <?= $e['type'] == 'Salary Payment' ? 'text-success' : 'text-warning' ?>">Rs. <?= number_format($e['amount'], 2) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/header.php'; ?>
