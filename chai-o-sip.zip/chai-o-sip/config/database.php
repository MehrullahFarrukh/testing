<?php
/**
 * Global Configuration & Database Connection
 */

$config = [
    'db_host' => 'localhost',
    'db_name' => 'chai_o_sip',
    'db_user' => 'root',
    'db_pass' => '',
    'db_char' => 'utf8mb4'
];

$dsn = "mysql:host={$config['db_host']};dbname={$config['db_name']};charset={$config['db_char']}";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $config['db_user'], $config['db_pass'], $options);
} catch (\PDOException $e) {
    die("Database Connection Error: " . $e->getMessage());
}
?>
