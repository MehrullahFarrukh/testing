<?php
require_once 'config/database.php';

if (session_status() === PHP_SESSION_NONE) { session_start(); }
$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']);

// Ensure 'cafe_tables' table exists
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS cafe_tables (
        id INT AUTO_INCREMENT PRIMARY KEY,
        table_name VARCHAR(255) UNIQUE NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
} catch (PDOException $e) {}

// Add Table
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_table'])) {
    $table_name = filter_input(INPUT_POST, 'table_name', FILTER_SANITIZE_SPECIAL_CHARS);
    
    try {
        $stmt = $pdo->prepare("INSERT INTO cafe_tables (table_name) VALUES (?)");
        $stmt->execute([$table_name]);
        $_SESSION['message'] = ['type' => 'success', 'text' => "Table '$table_name' added successfully."];
    } catch (PDOException $e) {
        $_SESSION['message'] = ['type' => 'danger', 'text' => "Error: Table might already exist."];
    }
    header("Location: tables.php");
    exit;
}

// Delete Table
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $pdo->prepare("DELETE FROM cafe_tables WHERE id = ? AND table_name != 'Takeaway'")->execute([$id]);
    $_SESSION['message'] = ['type' => 'success', 'text' => "Table removed."];
    header("Location: tables.php");
    exit;
}

$stmt = $pdo->query("SELECT * FROM cafe_tables ORDER BY id ASC");
$tables = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="mb-4 d-flex justify-content-between align-items-center">
    <div>
        <h2 class="fw-bold mb-1">Table Manager</h2>
        <p class="text-dim small mb-0">Add or remove tables and service areas.</p>
    </div>
    <button class="btn btn-primary rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#addTableModal">
        <i class="fas fa-plus me-2"></i> Add New Table
    </button>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card p-0 border-0 shadow-sm overflow-hidden">
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4">ID</th>
                            <th>Table Name</th>
                            <th>Created At</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($tables as $t): ?>
                        <tr>
                            <td class="ps-4 text-dim"><?= $t['id'] ?></td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="bg-primary bg-opacity-10 p-2 rounded-3 text-primary me-3">
                                        <i class="fas fa-chair"></i>
                                    </div>
                                    <span class="fw-bold"><?= htmlspecialchars($t['table_name']) ?></span>
                                </div>
                            </td>
                            <td class="small text-dim"><?= date('M d, Y', strtotime($t['created_at'])) ?></td>
                            <td class="text-end pe-4">
                                <?php if($t['table_name'] != 'Takeaway'): ?>
                                <a href="?delete=<?= $t['id'] ?>" class="btn btn-sm btn-outline-danger border-0" onclick="return confirm('Remove this table?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                                <?php else: ?>
                                <span class="badge bg-input text-dim">System Default</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Table Modal -->
<div class="modal fade" id="addTableModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-card border-0 shadow-lg">
            <form method="POST">
                <div class="modal-header border-light border-opacity-10">
                    <h5 class="modal-title fw-bold">Add New Table</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Table Name / Number</label>
                        <input type="text" name="table_name" class="form-control" placeholder="e.g. Table 15 or Garden Area" required>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="submit" name="add_table" class="btn btn-primary w-100 rounded-pill py-3 fw-bold">Create Table</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
