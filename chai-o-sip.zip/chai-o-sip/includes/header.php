<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Global ERP - Management System</title>
    
    <!-- Dependencies -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/main.css">
    <style>
        /* Modern Dark Theme - Visibility Overrides */
        body, p, span, label, td, th, h1, h2, h3, h4, h5, h6, .form-label, .card, .table {
            color: #ffffff; 
        }
        
        /* Secondary Text */
        .text-dim, .text-muted, .small, .extra-small {
            color: #94a3b8 !important;
            opacity: 0.9;
        }

        /* Status Colors - MUST BE HIGH PRIORITY */
        .text-success, .trend-up { color: #10b981 !important; }
        .text-danger, .trend-down { color: #ef4444 !important; }
        .text-warning { color: #f59e0b !important; }
        .text-primary { color: #3b82f6 !important; }

        /* Input Formatting */
        input::placeholder, textarea::placeholder { color: rgba(255,255,255,0.3) !important; }
        
        input, select, textarea {
            color: #ffffff !important;
            background-color: var(--bg-input) !important;
            border: 1px solid var(--border) !important;
        }

        .badge { color: #ffffff !important; }
        .table-dark { --bs-table-bg: transparent !important; }
    </style>
</head>
<body>

<div id="wrapper">
    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <h3>
                <div class="bg-primary p-2 rounded-3 me-2 d-inline-flex">
                    <i class="fas fa-cube text-white fa-xs"></i>
                </div>
                Global ERP
            </h3>
        </div>

        <ul class="list-unstyled components">
            <?php
            $current_page = basename($_SERVER['PHP_SELF']);
            $menu_items = [
                ['url' => 'index.php', 'icon' => 'fas fa-grid-2', 'default_icon' => 'fas fa-th-large', 'label' => 'Home'],
                ['url' => 'sales.php', 'icon' => 'fas fa-cart-shopping', 'default_icon' => 'fas fa-shopping-cart', 'label' => 'Cafe POS'],
                ['url' => 'menu.php', 'icon' => 'fas fa-book-open', 'default_icon' => 'fas fa-book-open', 'label' => 'Menu Manager'],
                ['url' => 'expenses.php', 'icon' => 'fas fa-wallet', 'default_icon' => 'fas fa-wallet', 'label' => 'Expenses'],
                ['url' => 'inventory.php', 'icon' => 'fas fa-box-archive', 'default_icon' => 'fas fa-boxes', 'label' => 'Stock'],
                ['url' => 'vendors.php', 'icon' => 'fas fa-handshake', 'default_icon' => 'fas fa-truck', 'label' => 'Suppliers'],
                ['url' => 'labour.php', 'icon' => 'fas fa-users-gear', 'default_icon' => 'fas fa-users', 'label' => 'Staff'],
                ['url' => 'reports.php', 'icon' => 'fas fa-file-chart-column', 'default_icon' => 'fas fa-file-invoice', 'label' => 'Reports']
            ];

            foreach ($menu_items as $item):
                $active = ($current_page == $item['url']) ? 'active' : '';
                // Special case for subpages
                if ($current_page == 'labour_ledger.php' && $item['url'] == 'labour.php') $active = 'active';
                if ($current_page == 'vendor_details.php' && $item['url'] == 'vendors.php') $active = 'active';
            ?>
            <li class="<?= $active ?>">
                <a href="<?= $item['url'] ?>">
                    <i class="<?= $item['icon'] ?> <?= $item['default_icon'] ?>"></i> 
                    <span><?= $item['label'] ?></span>
                </a>
            </li>
            <?php endforeach; ?>
        </ul>

        <div class="sidebar-footer mt-auto p-4 border-top border-light border-opacity-10" style="position: absolute; bottom: 0; width: 100%;">
            <div class="d-flex align-items-center">
                <img src="https://ui-avatars.com/api/?name=Alex+Rivera&background=0D8ABC&color=fff" class="rounded-circle me-3" width="40" alt="User">
                <div>
                    <h6 class="mb-0 small fw-bold">Alex Rivera</h6>
                    <span class="text-dim small" style="font-size: 0.7rem;">Admin Portal</span>
                </div>
                <i class="fas fa-cog ms-auto text-dim"></i>
            </div>
        </div>
    </nav>

    <!-- Page Content -->
    <div id="content">
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid p-0">
                <button type="button" id="sidebarCollapse" class="btn btn-outline-light border-opacity-10 me-3 d-lg-none">
                    <i class="fas fa-bars"></i>
                </button>
                <div class="search-bar d-none d-md-flex position-relative">
                    <i class="fas fa-search text-dim"></i>
                    <input type="text" id="globalSearch" placeholder="Search menu, stock, or staff..." autocomplete="off">
                    <div id="searchResults" class="position-absolute top-100 start-0 w-100 bg-card border border-light border-opacity-10 mt-2 rounded-3 shadow-lg d-none" style="z-index: 9999; max-height: 400px; overflow-y: auto;"></div>
                </div>
                
                <div class="ms-auto d-flex align-items-center gap-4">
                    <div class="position-relative">
                        <i class="far fa-bell text-dim fs-5"></i>
                        <span class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle"></span>
                    </div>
                    <i class="far fa-question-circle text-dim fs-5"></i>
                    <div class="dropdown">
                        <button class="btn btn-primary btn-sm px-4 rounded-pill dropdown-toggle" type="button" id="newEntryDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-plus me-2"></i> Add New
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end bg-card border-light border-opacity-10 shadow-lg" aria-labelledby="newEntryDropdown">
                            <li><a class="dropdown-item py-2 fw-bold" href="sales.php"><i class="fas fa-shopping-cart me-2 text-success"></i> Add Sale</a></li>
                            <li><a class="dropdown-item py-2 fw-bold" href="expenses.php"><i class="fas fa-wallet me-2 text-danger"></i> Add Expense</a></li>
                            <li><hr class="dropdown-divider border-light border-opacity-10"></li>
                            <li><a class="dropdown-item py-2 fw-bold" href="inventory.php"><i class="fas fa-boxes me-2 text-primary"></i> Add Stock</a></li>
                            <li><a class="dropdown-item py-2 fw-bold" href="vendors.php"><i class="fas fa-truck me-2 text-warning"></i> Pay Supplier</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid px-0">
            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-<?= $_SESSION['message']['type'] ?> alert-dismissible fade show border-0 shadow-lg mb-4" role="alert" style="background: var(--bg-card); color: var(--text-main); border-left: 4px solid var(--<?= $_SESSION['message']['type'] == 'success' ? 'success' : 'danger' ?>) !important;">
                    <div class="d-flex align-items-center">
                        <i class="fas <?= $_SESSION['message']['type'] == 'success' ? 'fa-check-circle text-success' : 'fa-exclamation-circle text-danger' ?> me-3 fs-4"></i>
                        <div>
                            <div class="fw-bold small"><?= $_SESSION['message']['type'] == 'success' ? 'Action Successful' : 'Attention Required' ?></div>
                            <div class="extra-small text-dim"><?= $_SESSION['message']['text'] ?></div>
                        </div>
                    </div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['message']); ?>
            <?php endif; ?>

